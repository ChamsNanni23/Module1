 document.write("Message from javascript<br/>");
do{   
   n=prompt("Enter a number");
   if(checkprime(n)){
   alert("Number is prime");
   }else{
   alert("Number is not prime");
   }
     while(confirm("Do you want to continue?"));
	 /****Function Definition****/
	 function checkprime(n){
   for(i=2;i<=(n/2);i++){
         if(n%i==0)
		 {
		 return false;
		 }
		 }
		 return true;
		 }
		