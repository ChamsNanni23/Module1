   document.write("Message from javascript<br/>");
do{   
   n=prompt("Enter a number");
   isprime=true;
   for(i=2;i<=(n/2);i++){
         if(n%i==0)
		 {
		 alert("Number is not prime..");
		  isprime=false;
		  break;
		  }
	}	  
		  if(isprime){
		  alert("Number is prime..");
		  }
    }
		  while(confirm("Do you want to continue?"));
