function validate(){
if(validateDoB() && validateState()){
var win=window.open();
var dobStr = frm1.dob.value;
var uname = frm1.txtUname.value;
var state=frm1.state.value;
var city=frm1.city.value;
win.document.write("<br/>Name:"+uname);
win.document.write("<br/>Date of Birth:"+dobStr);
win.document.write("<br/>State:"+state);
win.document.write("<br/>City:"+city);
return true;
}else{
return false;}
}
function validateDoB(){
var today=new Date();
var dob =frm1.dob.value;
var dob=new Date(dobStr);
if(dob>=today){
alert("Date of Birth should not be today or later");
return false;
}else{
return true;
}
}
function validateState(){

var state=frm1.state.value;
if(state=="None"){
alert("state");
frm1.state.focus();
}
var cityArr=[["Mumbai","Pune"],["Bangalore","Gulbarga"],["Chennai","Madurai"]];
function populateCity(){
var state=frm1.state.value;
var stateIdx=frm1.state.selectedIndex;
var city=frm1.city;
for(i=0;i<cityArr[stateIdx-1],length;i++){
var cityOption = new Option();
cityOption.text = cityArr[stateIdx-1][i];
city.options[i+1]=cityOption;
}
}